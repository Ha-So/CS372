This program was tested and runs on flip3. Make sure you're using flip3.

First, run the server by typing python chatServer.py [port #] Where port # is the number of the port you want
to run the server on.

Next, in a separate connection window, type make to generate the executable for the client.

Then run ./chatClient [flip3] [port #] where port # is the same port you specified for the server.

Important: first message must be sent from the client.

At any time (from the correct prompt, since the client and server alternate messages), type \quit to end the program